package server.handlers;

import server.game.GameState;

import java.io.IOException;
import java.util.LinkedList;

public class Lobby extends Thread {

    private GameState gameState;
    private MainHandler player11;
    private boolean isReady;
    private boolean isFull;
    private boolean isSomeOneWaiting;
    private boolean isFinished;
    private LinkedList<Integer> nums;

    public Lobby(GameState gameState) {
        this.isReady = false;
        this.gameState = gameState;
        isSomeOneWaiting = false;
        nums = new LinkedList<>();
        nums.add(1);
        nums.add(2);
    }

    @Override
    public synchronized void start() {
        super.start();
        try {
            prepPhase();
        } catch (IOException e) {
            e.printStackTrace();
        }

        while (!isFinished) {
        }
    }


    public synchronized void joinMatch(MainHandler player) {
        if (player11 != null) {
//            start();
            isReady = true;
            isFull = true;
        } else {
            player11 = player;
            isSomeOneWaiting = true;
        }
    }

    public void prepPhase() throws IOException {
        isFinished = false;
        gameState.startGame();
    }

    public int getNumber(){
        int a = nums.getLast();
        nums.removeLast();
        return a;
    }

    public boolean isFull() {
        return isFull;
    }

    public boolean isSomeOneWaiting() {
        return isSomeOneWaiting;
    }

    public GameState getGameState() {
        return gameState;
    }

    public boolean isReady() {
        return isReady;
    }
}

