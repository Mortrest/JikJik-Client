package server.handlers;

public class Events {

    static final String SIGN_IN = "SIGN_IN";
    static final String SIGN_UP = "SIGN_UP";
    static final String GAME = "GAME";
    static final String WAIT = "WAIT";
    static final String SPECTATE = "SPECTATE";
    static final String PROFILE = "PROFILE";
    static final String LEADERBOARD = "LEADERBOARD";
    static final String GO = "GO";
    static final String WATCH = "WATCH";

}
