package client.shared;

public class MyShips {
    int[][] myships;
    MyShips(int[][] myships){
        this.myships = myships;
    }

    public int[][] getMyships() {
        return myships;
    }
}
