package client.shared;

public class MainResponse {

    //    int type;
    int time;
    int turn;
    boolean isFinished;
    int[][] board1;
    int[][] board2;

    public MainResponse(int time, int turn, boolean isFinished, int[][] board1, int[][] board2) {
        this.time = time;
        this.turn = turn;
        this.isFinished = isFinished;
        this.board1 = board1;
        this.board2 = board2;
    }

    public int getTime() {
        return time;
    }

    public int getTurn() {
        return turn;
    }

    public boolean isFinished() {
        return isFinished;
    }

    public int[][] getBoard1() {
        return board1;
    }

    public int[][] getBoard2() {
        return board2;
    }
}

