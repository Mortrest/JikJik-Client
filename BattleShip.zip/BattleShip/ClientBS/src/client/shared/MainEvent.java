package client.shared;

public class MainEvent {
    String authToken;
    String command;

    public MainEvent(String authToken, String command) {
        this.authToken = authToken;
        this.command = command;
    }

    public String getAuthToken() {
        return authToken;
    }

    public String getCommand() {
        return command;
    }
}
