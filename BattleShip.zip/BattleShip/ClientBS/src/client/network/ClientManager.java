package client.network;

import client.shared.MainEvent;
import client.util.Manager;
import com.google.gson.Gson;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

public class ClientManager extends Thread {

    private Socket socket;
    Gson gson;
    private DataInputStream dataInputStream;
    private DataOutputStream dataOutputStream;
    private int playerType;

    public ClientManager() throws IOException {
        this.gson = new Gson();
        socket = new Socket("localhost", 8000);
        dataInputStream = new DataInputStream(socket.getInputStream());
        dataOutputStream = new DataOutputStream(socket.getOutputStream());
    }

    @Override
    public synchronized void start() {
        super.start();
    }


    public String read() throws IOException {
        return dataInputStream.readUTF();

    }


    public void sendClicked(String json) throws IOException {
        if (Manager.getAuthToken() != null) {
            MainEvent mainEvent = new MainEvent(Manager.getAuthToken(), json);
            String a = gson.toJson(mainEvent);
            dataOutputStream.writeUTF(a);
        } else {
            MainEvent mainEvent = new MainEvent("0", json);
            String a = gson.toJson(mainEvent);
            System.out.println(a);
            dataOutputStream.writeUTF(a);
        }
    }
}
