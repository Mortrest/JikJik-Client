package client.Controllers;

import javafx.fxml.FXML;
import javafx.scene.layout.AnchorPane;

public class CellController {

    @FXML
    private AnchorPane cell;

}
